import { createValidator } from 'express-joi-validation';

export default createValidator({});